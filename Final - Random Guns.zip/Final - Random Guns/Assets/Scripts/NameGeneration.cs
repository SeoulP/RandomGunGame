﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class NameGeneration : MonoBehaviour
{
    TMP_Text weaponName;
    string ranName;
    GameObject player;

    string[] elementType = new string[]
    {
        "Fire",
        "Earth",
        "Water",
        "Air"
    };
    string[] gunPrefixFire = new string[]
    {
        "Blazing ",
        "Burning ",
        "Erupting "
    };
    string[] gunPrefixEarth = new string[]
    {
        "Solid ",
        "Metallic ",
        "Stone "
    };
    string[] gunPrefixWater = new string[]
    {
        "Soaking ",
        "Tidal ",
        "Torrential "
    };
    string[] gunPrefixAir = new string[]
    {
        "Gusting ",
        "Whipping ",
        "Chilling "
    };
    string[] gunType = new string[] 
    {
        "Pistol",
        "Rifle",
        "Shotgun",
        "Machine Gun",
        "Rocket" 
    };
    string[] gunSuffix = new string[]
    {
        " of Eeriness",
        " of Suffocating",
        " of Pain",
        " of Hatred"
    };

    // Start is called before the first frame update
    void Start()
    {
        string currElement = elementType[Random.Range(0, elementType.Length)];
        string currPrefix = "";
        string currType = "";
        string currSuffix = "";
        if(currElement == "Fire")
        {
            currPrefix = gunPrefixFire[Random.Range(0, gunPrefixFire.Length)];
            gameObject.GetComponent<Renderer>().material.color = Color.red;
        }
        else if(currElement == "Earth")
        {
            currPrefix = gunPrefixEarth[Random.Range(0, gunPrefixEarth.Length)];
            gameObject.GetComponent<Renderer>().material.color = new Color(210,105,30);
        }
        else if (currElement == "Water")
        {
            currPrefix = gunPrefixWater[Random.Range(0, gunPrefixWater.Length)];
            gameObject.GetComponent<Renderer>().material.color = Color.blue;
        }
        else if (currElement == "Air")
        {
            currPrefix = gunPrefixAir[Random.Range(0, gunPrefixAir.Length)];
            gameObject.GetComponent<Renderer>().material.color = Color.white;
        }

        currType = gunType[Random.Range(0, gunType.Length)];
        currSuffix = gunSuffix[Random.Range(0, gunSuffix.Length)];
        
        player = GameObject.FindWithTag("Player");
        weaponName = gameObject.transform.GetChild(0).GetComponent<TextMeshPro>();
        weaponName.text = currPrefix + currType + currSuffix;
    }



    // Update is called once per frame
    void Update()
    {
        //Debug.Log(player.transform.position);
        weaponName.transform.LookAt(player.transform);

        Vector3 rot = weaponName.transform.rotation.eulerAngles;
        rot.x = 0;
        rot.y -= 180;
        weaponName.transform.eulerAngles = rot;
    }
}
